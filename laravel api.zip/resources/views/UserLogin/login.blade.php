@extends('layouts.app')
@section('content')
    <h1 class="text-bg-danger ">Hello</h1>
@endsection
