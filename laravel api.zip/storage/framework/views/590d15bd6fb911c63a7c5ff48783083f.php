<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <header>
        <?php if(!in_array(Route::currentRouteName(), 'create')): ?>
            <?php echo e(<?php echo $__env->make(, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 'includes.header'); ?>

        <?php endif; ?>
    </header>
    <?php echo $__env->yieldContent('content'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\LaravelTutor\resources\views/layouts/app.blade.php ENDPATH**/ ?>